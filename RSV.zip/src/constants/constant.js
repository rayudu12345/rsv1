export const messages = [
    {
      id: 1,
      from: "123@gmail.com",
      to: "456@gmail.com",
      subject:
        "Re: You can't input the protocol without calculating the mobile !",
      body:
        "In order to create a React component, we have to create a class that inherits from React.Component. That is exactly what the line class App extends Component does. All React components should implement a render method — as you may have guessed, all of the rendering is happening within this method. The render method has to return the markup to be rendered.",
      read: false,
      starred: true,
      date: "01-05-2019 12:00:16 am"
    },
  
    {
      id: 2,
      from: "789@gmail.com",
      to: "426@gmail.com",
      subject:
        "Re: You can't input the protocol without calculating the mobile !",
      body:
        "In order to create a React component, we have to create a class that inherits from React.Component. That is exactly what the line class App extends Component does. All React components should implement a render method — as you may have guessed, all of the rendering is happening within this method. The render method has to return the markup to be rendered.",
      read: false,
      starred: true,
      date: "02-03-2019 12:00:16 am"
    },
    
  ];
  