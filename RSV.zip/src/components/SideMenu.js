import React from "react";
import "../css/icomoon.css";
import "../css/common.css";
import "../css/table.css";
import "../css/sidebars.css";
import "../css/menu-details.css";
import logo from "../images/logo.png";
import user from "../images/user.png";

class SideMenu extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      subsideMenu: false,
    };
  }

  openPopUp() {
    this.setState({ subsideMenu: true });
  }
  closepopup() {
    this.setState({ subsideMenu: false });
  }

  render() {
    return (
      <div class="sidemenufull">
        <div class="sidebar_main">
          <div class="logo">
            <a href="" class="logo-sm">
              <img src={logo} alt="logo" />
            </a>
            <a href="" class="logo-expand">
              <img src={logo} alt="logo" />
            </a>
          </div>
          <nav class="nav">
            <div class="nav_list main_nav">
              <a href="#" class="nav_link">
                <i class="icon-home nav_icon"></i>
                <span class="nav_name">Home</span>
              </a>
              <a
                href="#"
                class="nav_link has_submenu"
                onClick={this.openPopUp.bind(this)}
              >
                <i class="icon-study nav_icon"></i>
                <span class="nav_name">Study</span>
              </a>
              <a href="#" class="nav_link">
                <i class="icon-contact nav_icon"></i>
                <span class="nav_name">Contacts</span>
              </a>
              <a href="#" class="nav_link">
                <i class="icon-sponsor nav_icon"></i>
                <span class="nav_name">Sponsor</span>
              </a>
              <a href="#" class="nav_link">
                <i class="icon-vendor nav_icon"></i>
                <span class="nav_name">Vendors</span>
              </a>
            </div>
            <div class="nav_list">
              <a href="#" class="nav_link">
                <i class="icon-notification nav_icon"></i>
                <span class="nav_name">Notifications</span>
              </a>
              <a href="#" class="nav_link">
                <i class="icon-setting nav_icon"></i>
                <span class="nav_name">Settings</span>
              </a>
              <a href="#" class="nav_link user">
                <img src={user} alt="user" />
                <span class="nav_name">User Name</span>
              </a>
              <a href="#" class="nav_link toggle">
                <i className="fa fa-bars"></i>
              </a>
            </div>
          </nav>
          {this.state.subsideMenu ? (
            <div class="menu_details">
              <span
                onClick={this.closepopup.bind(this)}
                className="close_sidemenu"
              ></span>
              <h3>Study</h3>
              <p>Here you will find list of options for Studies section.</p>
              <div class="nav">
                <div class="nav_list">
                  <a href="#" class="nav_sublink">
                    <i class="icon-add-study nav_icon"></i>
                    <span class="nav_name">Add Study</span>
                  </a>
                  <a href="#" class="nav_sublink">
                    <i class="icon-study-list nav_icon"></i>
                    <span class="nav_name">Study List</span>
                  </a>
                  <a href="#" class="nav_sublink">
                    <i class="icon-reports nav_icon"></i>
                    <span class="nav_name">Reports</span>
                  </a>
                </div>
              </div>
            </div>
          ) : null}
        </div>
      </div>
    );
  }
}

export default SideMenu;
