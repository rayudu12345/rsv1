import React from "react";
import { MDBDataTableV5, MDBIcon } from "mdbreact";
import "@fortawesome/fontawesome-free/css/all.min.css";
import "bootstrap-css-only/css/bootstrap.min.css";
import "mdbreact/dist/css/mdb.css";
import "../css/icomoon.css";
import "../css/common.css";
import "../css/table.css";
import "../css/main-content.css";
import { Redirect, Route, Switch } from "react-router";
import ReactApexChart from "react-apexcharts";
import Chart from "react-apexcharts";
import moment from "moment";
import { messages } from "../constants/constant";
import Select from "react-select";

class Home extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      action_dropdown: [
        { label: "Add Study", value: 1 },
        { label: "Study Upload", value: 2 },
        { label: "Reports", value: 3 },
        { label: "Study Settings", value: 4 },
        { label: "Delete", value: 5 },
      ],

      sponsor_name: [
        { label: "John Deo", value: 1 },
        { label: "Albert Tom", value: 2 },
      ],

      study_phase: [
        { label: "Phase 1", value: 1 },
        { label: "Phase 2", value: 2 },
        { label: "Phase 3", value: 3 },
      ],

      study_status: [
        { label: "Active", value: 1 },
        { label: "In Active", value: 2 },
      ],

      datatable: {
        columns: [
          {
            label: "Sponsor Name",
            field: "name",
            attributes: {
              "aria-controls": "DataTable",
              "aria-label": "Name",
            },
          },
          {
            label: "Protocol Number / IRB",
            field: "IRB",
          },
          {
            label: "Study Phase",
            field: "study",
          },
          {
            label: "Therapeutic Area",
            field: "therapeutic",
            sort: "asc",
          },
          {
            label: "Study Status",
            field: "status",
            sort: "disabled",
          },
          {
            label: "Actions",
            field: "actions",
            sort: "disabled",
          },
        ],
        rows: [
          {
            name: (
              <div className="tss-td-grid">
                <div className="profile">JD</div>
                <div className="name">
                  <label>John Deo</label>
                  <span>11-05-2021</span>
                </div>
              </div>
            ),
            IRB: "VS-TEST-RECIST-32717-4",
            study: "Phase 1",
            therapeutic: "RSV",
            status: <span className="active">Active</span>,
            actions: (
              <ul className="action_btns">
                <li>
                  <a href="" className="download">
                    <span class="icon-download"></span>
                  </a>
                </li>
                <li>
                  <a href="" className="edit">
                    <span class="icon-edit"></span>
                  </a>
                </li>
                <li>
                  <a href="" className="delete">
                    <span class="icon-delete"></span>
                  </a>
                </li>
              </ul>
            ),
          },
          {
            name: (
              <div className="tss-td-grid">
                <div className="profile">AT</div>
                <div className="name">
                  <label>Albert Tom</label>
                  <span>11-05-2021</span>
                </div>
              </div>
            ),
            IRB: "VS-TEST-RECIST-32717-3",
            study: "Phase 2",
            therapeutic: "RSV",
            status: <span className="inactive">InActive</span>,
            actions: (
              <ul className="action_btns">
                <li>
                  <a href="" className="download">
                    <span class="icon-download"></span>
                  </a>
                </li>
                <li>
                  <a href="" className="edit">
                    <span class="icon-edit"></span>
                  </a>
                </li>
                <li>
                  <a href="" className="delete">
                    <span class="icon-delete"></span>
                  </a>
                </li>
              </ul>
            ),
          },
          {
            name: (
              <div className="tss-td-grid">
                <div className="profile">JD</div>
                <div className="name">
                  <label>John Deo</label>
                  <span>11-05-2021</span>
                </div>
              </div>
            ),
            IRB: "VS-TEST-RECIST-32717-4",
            study: "Phase 1",
            therapeutic: "RSV",
            status: <span className="active">Active</span>,
            actions: (
              <ul className="action_btns">
                <li>
                  <a href="" className="download">
                    <span class="icon-download"></span>
                  </a>
                </li>
                <li>
                  <a href="" className="edit">
                    <span class="icon-edit"></span>
                  </a>
                </li>
                <li>
                  <a href="" className="delete">
                    <span class="icon-delete"></span>
                  </a>
                </li>
              </ul>
            ),
          },
          {
            name: (
              <div className="tss-td-grid">
                <div className="profile">AT</div>
                <div className="name">
                  <label>Albert Tom</label>
                  <span>11-05-2021</span>
                </div>
              </div>
            ),
            IRB: "VS-TEST-RECIST-32717-3",
            study: "Phase 2",
            therapeutic: "RSV",
            status: <span className="inactive">InActive</span>,
            actions: (
              <ul className="action_btns">
                <li>
                  <a href="" className="download">
                    <span class="icon-download"></span>
                  </a>
                </li>
                <li>
                  <a href="" className="edit">
                    <span class="icon-edit"></span>
                  </a>
                </li>
                <li>
                  <a href="" className="delete">
                    <span class="icon-delete"></span>
                  </a>
                </li>
              </ul>
            ),
          },
          {
            name: (
              <div className="tss-td-grid">
                <div className="profile">JD</div>
                <div className="name">
                  <label>John Deo</label>
                  <span>11-05-2021</span>
                </div>
              </div>
            ),
            IRB: "VS-TEST-RECIST-32717-4",
            study: "Phase 1",
            therapeutic: "RSV",
            status: <span className="active">Active</span>,
            actions: (
              <ul className="action_btns">
                <li>
                  <a href="" className="download">
                    <span class="icon-download"></span>
                  </a>
                </li>
                <li>
                  <a href="" className="edit">
                    <span class="icon-edit"></span>
                  </a>
                </li>
                <li>
                  <a href="" className="delete">
                    <span class="icon-delete"></span>
                  </a>
                </li>
              </ul>
            ),
          },
          {
            name: (
              <div className="tss-td-grid">
                <div className="profile">AT</div>
                <div className="name">
                  <label>Albert Tom</label>
                  <span>11-05-2021</span>
                </div>
              </div>
            ),
            IRB: "VS-TEST-RECIST-32717-3",
            study: "Phase 2",
            therapeutic: "RSV",
            status: <span className="inactive">InActive</span>,
            actions: (
              <ul className="action_btns">
                <li>
                  <a href="" className="download">
                    <span class="icon-download"></span>
                  </a>
                </li>
                <li>
                  <a href="" className="edit">
                    <span class="icon-edit"></span>
                  </a>
                </li>
                <li>
                  <a href="" className="delete">
                    <span class="icon-delete"></span>
                  </a>
                </li>
              </ul>
            ),
          },
          {
            name: (
              <div className="tss-td-grid">
                <div className="profile">JD</div>
                <div className="name">
                  <label>John Deo</label>
                  <span>11-05-2021</span>
                </div>
              </div>
            ),
            IRB: "VS-TEST-RECIST-32717-4",
            study: "Phase 1",
            therapeutic: "RSV",
            status: <span className="active">Active</span>,
            actions: (
              <ul className="action_btns">
                <li>
                  <a href="" className="download">
                    <span class="icon-download"></span>
                  </a>
                </li>
                <li>
                  <a href="" className="edit">
                    <span class="icon-edit"></span>
                  </a>
                </li>
                <li>
                  <a href="" className="delete">
                    <span class="icon-delete"></span>
                  </a>
                </li>
              </ul>
            ),
          },
          {
            name: (
              <div className="tss-td-grid">
                <div className="profile">AT</div>
                <div className="name">
                  <label>Albert Tom</label>
                  <span>11-05-2021</span>
                </div>
              </div>
            ),
            IRB: "VS-TEST-RECIST-32717-3",
            study: "Phase 2",
            therapeutic: "RSV",
            status: <span className="inactive">InActive</span>,
            actions: (
              <ul className="action_btns">
                <li>
                  <a href="" className="download">
                    <span class="icon-download"></span>
                  </a>
                </li>
                <li>
                  <a href="" className="edit">
                    <span class="icon-edit"></span>
                  </a>
                </li>
                <li>
                  <a href="" className="delete">
                    <span class="icon-delete"></span>
                  </a>
                </li>
              </ul>
            ),
          },
          {
            name: (
              <div className="tss-td-grid">
                <div className="profile">JD</div>
                <div className="name">
                  <label>John Deo</label>
                  <span>11-05-2021</span>
                </div>
              </div>
            ),
            IRB: "VS-TEST-RECIST-32717-4",
            study: "Phase 1",
            therapeutic: "RSV",
            status: <span className="active">Active</span>,
            actions: (
              <ul className="action_btns">
                <li>
                  <a href="" className="download">
                    <span class="icon-download"></span>
                  </a>
                </li>
                <li>
                  <a href="" className="edit">
                    <span class="icon-edit"></span>
                  </a>
                </li>
                <li>
                  <a href="" className="delete">
                    <span class="icon-delete"></span>
                  </a>
                </li>
              </ul>
            ),
          },
          {
            name: (
              <div className="tss-td-grid">
                <div className="profile">AT</div>
                <div className="name">
                  <label>Albert Tom</label>
                  <span>11-05-2021</span>
                </div>
              </div>
            ),
            IRB: "VS-TEST-RECIST-32717-3",
            study: "Phase 2",
            therapeutic: "RSV",
            status: <span className="inactive">InActive</span>,
            actions: (
              <ul className="action_btns">
                <li>
                  <a href="" className="download">
                    <span class="icon-download"></span>
                  </a>
                </li>
                <li>
                  <a href="" className="edit">
                    <span class="icon-edit"></span>
                  </a>
                </li>
                <li>
                  <a href="" className="delete">
                    <span class="icon-delete"></span>
                  </a>
                </li>
              </ul>
            ),
          },
        ],
      },

      options: {
        chart: {
          zoom: {
            enabled: false,
          },
        },
        stroke: {
          curve: "smooth",
        },
        fill: {
          type: "solid",
          opacity: [0.35, 1],
        },
        markers: {
          size: 0,
        },
        tooltip: {
          shared: true,
          intersect: false,
          y: {
            formatter: function (y) {
              if (typeof y !== "undefined") {
                return y.toFixed(0) + " points";
              }
              return y;
            },
          },
        },
      },
      series: [
        {
          name: "Active",
          type: "area",
          data: [0, 20, 30, 40, 30, 20, 40, 60, 70, 0],
        },
        {
          name: "In Active",
          type: "line",
          data: [0, 10, 20, 30, 20, 10, 30, 50, 60, 0],
        },
      ],

      pie_options: {
        chart: {
          type: "donut",
        },
        responsive: [
          {
            breakpoint: 991,
            options: {
              chart: {
                width: 200,
              },
              legend: {
                position: "bottom",
              },
            },
          },
        ],
        labels: ["Phase 1", "Phase 2", "Phase 3"],
        dataLabels: {
          enabled: false,
        },
      },
      pie_services: [10, 20, 20],

      bar_services: [
        {
          name: "series-1",
          data: [30, 40, 50, 40, 60, 80, 50, 20, 40, 60],
        },
      ],
      bar_options: {
        chart: {
          id: "basic-bar",
        },
        dataLabels: {
          enabled: false,
        },
        xaxis: {
          categories: [,],
        },
      },
    };
  }

  render() {
    return (
      <div className="main_content">
        <div className="page_content">
          <div className="row g-3 mb-3 mx-0">
            <div className="col-6">
              <div className="page_head">
                <h2 className="page_title">Study List</h2>
              </div>
            </div>
            <div className="col-6">
              <div className="action-dropdown">
                <div className="dropdown hover-dropdown">
                  <Select
                    options={this.state.action_dropdown}
                    placeholder="Actions"
                  />
                </div>
              </div>
            </div>
          </div>

          <div className="row g-3 mx-0 py-3 tss-tab-reverse">
            <div className="col-xl-9 tss-relative">
              <div className="row g-3 mb-3 mx-0">
                <div className="col-12">
                  <div className="filters_group tss-absolute ">
                    <div className="filter">
                      <label>Sponsor Name</label>
                      <Select
                        options={this.state.sponsor_name}
                        placeholder="All"
                      />
                    </div>
                    <div className="filter">
                      <label>Study Phase</label>
                      <Select
                        options={this.state.study_phase}
                        placeholder="All"
                      />
                    </div>
                    <div className="filter">
                      <label>Status</label>
                      <Select
                        options={this.state.study_status}
                        placeholder="All"
                      />
                    </div>
                  </div>
                </div>
              </div>
              <div>
                {
                  <MDBDataTableV5
                    hover
                    entriesOptions={[5, 20, 25]}
                    entries={5}
                    pagesAmount={4}
                    data={this.state.datatable}
                    searchTop
                    searchBottom={false}
                    materialSearch
                    entriesLabel="Results  "
                    paginationLabel={["Previous", "Next"]}
                    responsive={true}
                  />
                }
              </div>
            </div>

            <div className="col-xl-3">
              <div className="charts">
                <div className="row g-3">
                  <div className="col-xl-12 col-lg-4 col-md-4 mb-3">
                    <div className="px-1 pt-3 bg-light tss_rounded h-100">
                      <h4 className="text-gray fs-12 px-3">
                        ACTIVE / INACTIVE STATUS
                      </h4>
                      <div className="w-100 pr-2">
                        <ReactApexChart
                          options={this.state.options}
                          series={this.state.series}
                          type="line"
                        />
                      </div>
                    </div>
                  </div>
                  <div className="col-xl-12 col-lg-4 col-md-4 mb-3">
                    <div className="px-1 pt-3 bg-light tss_rounded h-100">
                      <h4 className="text-gray fs-12 px-3">
                        BT SPONSORED NAME
                      </h4>
                      <div className="w-100 pr-2">
                        <Chart
                          options={this.state.bar_options}
                          series={this.state.bar_services}
                          type="bar"
                        />
                      </div>
                    </div>
                  </div>
                  <div className="col-xl-12 col-lg-4 col-md-4 mb-3">
                    <div className="p-3 bg-light tss_rounded h-100">
                      <h4 className="text-gray fs-12">BT THERAPEUTIC AREA</h4>
                      <div className="w-100">
                        <Chart
                          options={this.state.pie_options}
                          series={this.state.pie_services}
                          type="donut"
                        />
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default Home;
