import "../css/icomoon.css";
import "../css/common.css";
import "../css/table.css";
import "../css/main-content.css";
import dataJson from "./dataList.json";
import dropdownJson from "./dropDown.json";
var rows_data = [],
  columns_data = [];
dataJson.rows.map((data) => {
  rows_data.push({
    name: (
      <div className="tss-td-grid">
        <div className="profile">{data.shortcut}</div>
        <div className="name">
          <label>{data.name}</label>
          <span>{data.date}</span>
        </div>
      </div>
    ),
    IRB: <p>{data.irb}</p>,
    study: <p>{data.study}</p>,
    therapeutic: <p>{data.therapeutic}</p>,
    status: <span className="active">{data.status}</span>,
    actions: (
      <ul className="action_btns">
        <li>
          <a href="" className="download">
            <span class="icon-download"></span>
          </a>
        </li>
        <li>
          <a href="" className="edit">
            <span class="icon-edit"></span>
          </a>
        </li>
        <li>
          <a href="" className="delete">
            <span class="icon-delete"></span>
          </a>
        </li>
      </ul>
    ),
  });
});
dataJson.columns.map((columns) => {
  columns_data.push({
    [columns.lableKey]: columns.labelValue,
    [columns.filedkey]: columns.fieldValue,
  });
});
var action_drop = [];
dropdownJson.action_dropdown.map((actions) => {
  action_drop.push({
    [actions.labelKey]: actions.label,
    [actions.valueKey]: actions.value,
  });
});
export const study_datalist = {
  columns: columns_data,
  rows: rows_data,
};

export const action_dropdown = action_drop;

var sponsor_name_json = [];
dropdownJson.sponsor_name.map((sp) => {
  sponsor_name_json.push({ [sp.labelKey]: sp.label, [sp.valueKey]: sp.value });
});
export const sponsor_name = sponsor_name_json;

var study_phase_json = [];
dropdownJson.study_phase.map((study) => {
  study_phase_json.push({
    [study.labelKey]: study.label,
    [study.valueKey]: study.value,
  });
});

export const study_phase = study_phase_json;

var study_status_json = [];
dropdownJson.study_status.map((status) => {
  study_status_json.push({
    [status.labelKey]: status.label,
    [status.valueKey]: status.value,
  });
});
export const study_status = study_status_json;

export const lineGraph = {
  options: {
    chart: {
      zoom: {
        enabled: false,
      },
    },
    stroke: {
      curve: "smooth",
    },
    fill: {
      type: "solid",
      opacity: [0.35, 1],
    },
    markers: {
      size: 0,
    },
    dataLabels: {
      enabled: false,
    },
    tooltip: {
      shared: true,
      intersect: false,
      y: {
        formatter: function (y) {
          if (typeof y !== "undefined") {
            return y.toFixed(0) + " Records";
          }
          return y;
        },
      },
    },
  },
  services: [
    {
      name: "Active",
      type: "area",
      data: [0, 20, 30, 40, 30, 20, 40, 60, 70, 0],
    },
    {
      name: "In Active",
      type: "line",
      data: [0, 10, 20, 30, 20, 10, 30, 50, 60, 0],
    },
  ],
};

export const pieGraph = {
  options: {
    chart: {
      type: "donut",
      id: "basic-bar",
    },
    responsive: [
      {
        breakpoint: 991,
        options: {
          chart: {
            width: 200,
          },
          legend: {
            position: "bottom",
          },
        },
      },
    ],
    labels: ["Phase 1", "Phase 2", "Phase 3"],

    dataLabels: {
      enabled: false,
    },
  },
  services: [10, 20, 20],
};

export const barGraph = {
  services: [
    {
      name: "",
      data: [30, 40, 50, 40, 60, 80, 50, 20, 40, 60],
    },
  ],
  options: {
    chart: {
      id: "basic-bar",
    },
    dataLabels: {
      enabled: false,
    },
    xaxis: {
      categories: [,],
    },
  },
};
